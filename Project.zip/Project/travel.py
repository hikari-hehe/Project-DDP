import streamlit as st

# Class untuk struktur data perjalanan
class Perjalanan:
    def __init__(self, negara, budget, jumlah_orang, lama_hari):
        self.negara = negara
        self.budget = budget
        self.jumlah_orang = jumlah_orang
        self.lama_hari = lama_hari

    def estimasi_biaya_per_hari(self):
        return self.budget / (self.jumlah_orang * self.lama_hari)

def main():
    st.set_page_config(page_title="Autumn Travel", layout="centered")

    # Sidebar Design
    with st.sidebar:
        st.title("Menu")
        menu = ["Tentang Aplikasi", "Halaman Utama", "Transportasi", "Rekomendasi", "Paket Wisata", "FAQ"]
        pilihan = st.selectbox("Pilih Menu", menu)

        # Informasi user yang sudah input
        if "perjalanan" in st.session_state:
            st.divider()
            st.subheader("Informasi Perjalanan")
            perjalanan = st.session_state["perjalanan"]
            st.write(f"🌏 Negara: {perjalanan.negara}")
            st.write(f"💰 Budget: IDR{perjalanan.budget:,.0f}")
            st.write(f"👥 Jumlah Orang: {perjalanan.jumlah_orang}")
            st.write(f"📅 Lama Hari: {perjalanan.lama_hari}")

    # Konten utama berdasarkan menu
    if pilihan == "Tentang Aplikasi":
        halaman_about()
    elif pilihan == "Halaman Utama":
        halaman_utama()
    elif pilihan == "Transportasi":
        halaman_transportasi()
    elif pilihan == "Rekomendasi":
        halaman_rekomendasi()
    elif pilihan == "Paket Wisata":
        halaman_paket_wisata()
    elif pilihan == "FAQ":
        halaman_faq()

def halaman_about():
    st.title("Autumn Travel")
    st.write("Aplikasi ini adalah Aplikasi Travel: Autumn Travel yang dapat membantu merencanakan perjalanan wisata dengan mudah melalui fitur. Aplikasi ini dirancang untuk mempermudah perencanaan perjalanan wisata pengguna secara efisien.")
    st.write("Perjalanan seperti negara tujuan (Singapura, Thailand, atau Malaysia), jumlah orang, lama perjalanan, dan budget, untuk menghitung estimasi biaya per orang per hari.")
    st.write("Aplikasi juga menyediakan informasi lengkap tentang transportasi (penerbangan, transportasi lokal, dan sewa kendaraan), rekomendasi hotel, restoran, dan tempat wisata populer di negara tujuan, serta paket wisata yang bisa dipilih sesuai kebutuhan.")
    st.write("Jika ada pertanyaan mengenai perjalanan tersedia menu FAQ untuk menjawab pertanyaan umum terkait aplikasi.")
    st.write("Terima kasih telah menggunakan aplikasi ini!")
    st.subheader("Anggota Kelompok")
    st.write("1. Ketua Kelompok : Zahra Aulia Rahmani (0110224193)")
    st.write("2. Anggota Kelompok : Autumm Zebtotanel (0110224058)")
    st.write("3. Anggota Kelompok : Hasna Ghaniyyah (0110224062)")
    st.write("4. Anggota Kelompok : Shapiere Januar Rafiansyah (0110224191)")
def halaman_utama():
    st.header("Autumn Travel!🌍")

    st.subheader("Detail Perjalanan")
    negara = st.selectbox("Pilih Negara Tujuan", ["Singapura", "Thailand", "Malaysia"], key="negara")
    jumlah_orang = st.number_input("Jumlah Orang", min_value=1, step=1, key="jumlah_orang")
    lama_hari = st.number_input("Lama Hari", min_value=1, step=1, key="lama_hari")

    budget = None
    # Validasi budget menggunakan while looping
    while budget is None or budget < 10000000:
        budget = st.number_input(
            "Budget (IDR, minimal 10 juta)",
            min_value=0.0,
            step=5000000.0,
            key="budget"
        )
        if budget < 10000000:
            st.error("❗Budget harus minimal IDR 10.000.000. Harap masukkan nilai yang lebih besar.")
            return

    if st.button("Simpan Data", type="primary", key="simpan_data"):
        perjalanan = Perjalanan(negara, budget, jumlah_orang, lama_hari)
        st.session_state["perjalanan"] = perjalanan
        st.success("Data Berhasil Disimpan!")

        # Tampilkan estimasi biaya sederhana
        biaya_per_hari = perjalanan.estimasi_biaya_per_hari()
        st.subheader("Estimasi Biaya per Orang per Hari")
        st.info(f"💰 IDR{biaya_per_hari:,.0f}")

def halaman_transportasi():
    st.header("Transportasi✈️")

    if "perjalanan" not in st.session_state:
        st.warning("Silakan isi data di Halaman Utama terlebih dahulu.")
        return

    perjalanan = st.session_state["perjalanan"]

    tab1, tab2, tab3 = st.tabs(["Pesawat", "Transport Lokal", "Rental"])

    with tab1:
        st.subheader("Pilihan Penerbangan")
        kelas_pesawat = st.selectbox("Kelas Pesawat", ["Ekonomi", "Bisnis", "VIP"], key="kelas_pesawat")
        maskapai = st.selectbox("Maskapai", ["Garuda Indonesia", "Lion Air", "Air Asia"], key="maskapai")

        harga_tiket = {
            "Ekonomi": {"Garuda Indonesia": 3000000, "Lion Air": 1500000, "Air Asia": 1800000},
            "Bisnis": {"Garuda Indonesia": 7000000, "Lion Air": 2000000, "Air Asia": 2200000},
            "VIP": {"Garuda Indonesia": 13500000, "Lion Air": 10000000, "Air Asia": 12000000}
        }

        harga = harga_tiket[kelas_pesawat][maskapai]
        st.info(f"Estimasi harga tiket: IDR{harga} per orang")

    with tab2:
        st.subheader("Transport Lokal")
        transport_info = {
            "Singapura": ["🚇 MRT: $1-2 per trip", "🚕 Taxi: $3 base fare + $0.22/km", "🚌 Bus: $1-2 per trip"],
            "Thailand": ["🚇 BTS: 15-50 THB per trip", "🚕 Taxi: 35 THB base fare + 5 THB/km", "🚌 Bus: 8-20 THB per trip"],
            "Malaysia": ["🚇 Train: RM5.00 per trip", "🚕 Taxi: RM20.00 base fare + RM10.00/km", "🚌 Bus: RM3.00-5.00 per trip"]
        }

        for info in transport_info.get(perjalanan.negara, []):
            st.write(info)

    with tab3:
        st.subheader("Rental Kendaraan")
        jenis_kendaraan = st.selectbox("Jenis Kendaraan", ["Motor", "Mobil", "Van"], key="jenis_kendaraan")
        lama_sewa = st.number_input("Lama Sewa (hari)", min_value=1, step=1, key="lama_sewa")

        harga_sewa = {"Motor": 400000, "Mobil": 800000, "Van": 1300000}

        total_sewa = harga_sewa[jenis_kendaraan] * lama_sewa
        st.info(f"Estimasi biaya sewa: IDR{total_sewa} total")

def halaman_rekomendasi():
    st.header("Rekomendasi🎯")

    if "perjalanan" not in st.session_state:
        st.warning("Silakan isi data di Halaman Utama terlebih dahulu.")
        return

    perjalanan = st.session_state["perjalanan"]
    negara = perjalanan.negara

    rekomendasi_data = {
        "Singapura": {
            "Hotel 🏨": ["Marina Bay Sands", "Raffles Hotel", "Hotel Boss"],
            "Restoran 🍽️": ["Maxwell Food Centre", "Lau Pa Sat", "Jumbo Seafood"],
            "Wisata 🎪": ["Gardens by the Bay", "Universal Studios", "Sentosa Island"]
        },
        "Thailand": {
            "Hotel 🏨": ["Mandarin Oriental", "The Peninsula", "Lub d"],
            "Restoran 🍽️": ["Jay Fai", "Som Tam Nua", "Raan Jay Fai"],
            "Wisata 🎪": ["Grand Palace", "Wat Arun", "Chatuchak Weekend Market"]
        },
        "Malaysia": {
            "Hotel 🏨": ["Ritz-Carlton", "Four Seasons", "Tune Hotel"],
            "Restoran 🍽️": ["Lot 10 Hutong", "Village Park Restaurant", "Madam Kwan's"],
            "Wisata 🎪": ["Petronas Towers", "Batu Caves", "Jonker Street"]
        }
    }

    image_paths = {
        "Singapura": {
            "Hotel 🏨": ["Project/img/Marina SB.jpg",  "Project/img/Rafless.jpg", "Project/img/Hotel Boss.jpg"],
            "Restoran 🍽️": ["Project/img/7.resMaxwell.jpg", "Project/img/9.resLaupasat.jpg", "Project/img/8.resJumboseafood.jpg"],
            "Wisata 🎪": ["Project/img/10.wisataGardens.jpg", "Project/img/11.universal.jpeg", "Project/img/12.sentosaIsland.jpg"]
        },
        "Thailand": {
            "Hotel 🏨": ["Project/img/Thai/Mandarin_Oriental.jpg", "Project/img/Thai/The_Peninsula.jpg", "Project/img/Thai/Lub_d.jpg"],
            "Restoran 🍽️": ["Project/img/Thai/Jay_Fai.jpg", "Project/img/Thai/Som_Tam-Nua.png", "Project/img/Thai/Raan_Jay_Fai.jpg"],
            "Wisata 🎪": ["Project/img/Thai/Grand_Palace.jpg", "Project/img/Thai/Wat_Arun.jpg", "Project/img/Thai/Chatuchak_Weekend_Market.jpg"]
        },
        "Malaysia": {
            "Hotel 🏨": ["Project/img/Ritz-Carlton.jpg", "Project/img/Four Seasons.jpeg", "Project/img/Tune Hotel.jpg"],
            "Restoran 🍽️": ["Project/img/Lot 10 Hutong.jpg", "Project/img/Village Park Restaurant.jpg", "Project/img/Madam Kwan's.jpg"],
            "Wisata 🎪": ["Project/img/Petronas Towers.jpg", "Project/img/Batu Caves.jpg", "Project/img/Jonker Street.jpg"]
        }
    }

    if negara in rekomendasi_data:
        for kategori, rekomendasi in rekomendasi_data[negara].items():
            st.subheader(kategori)
            for i, item in enumerate(rekomendasi):
                st.write(f"- {item}")
                if negara in image_paths and kategori in image_paths[negara]:
                    st.image(image_paths[negara][kategori][i], use_container_width=True)

def halaman_paket_wisata():
    st.header("Paket Wisata📦")

    if "perjalanan" not in st.session_state:
        st.warning("Silakan isi data di Halaman Utama terlebih dahulu.")
        return

    perjalanan = st.session_state["perjalanan"]
    negara = perjalanan.negara

    paket_data = {
        "Singapura": {
            "Hemat": {"harga": 8000000, "durasi": "3D2N", "hotel": "Hotel 81", "includes": ["Hotel", "Transport Pass", "City Tour"]},
            "Standard": {"harga": 13000000, "durasi": "4D3N", "hotel": "Village Hotel", "includes": ["Hotel", "Transport Pass", "City Tour", "Universal Studios"]},
            "Premium": {"harga": 19500000, "durasi": "5D4N", "hotel": "Marina Bay Sands", "includes": ["Hotel", "Transport Pass", "City Tour", "Universal Studios", "Gardens by the Bay", "River Cruise"]}
        },
        "Thailand": {
            "Hemat": {"harga": 7000000, "durasi": "3D2N", "hotel": "Lub d Hostel", "includes": ["Hotel", "Transport Lokal", "City Tour"]},
            "Standard": {"harga": 11000000, "durasi": "4D3N", "hotel": "Holiday Inn", "includes": ["Hotel", "Transport Lokal", "City Tour", "Wat Arun"]},
            "Premium": {"harga": 18000000, "durasi": "5D4N", "hotel": "The Peninsula", "includes": ["Hotel", "Transport Lokal", "City Tour", "Wat Arun", "Grand Palace"]}
        }
    }

    if negara in paket_data:
        for tipe, detail in paket_data[negara].items():
            with st.expander(f"Paket {tipe} - IDR{detail['harga']}/orang"):
                st.write(f"Durasi: {detail['durasi']}")
                st.write(f"Hotel: {detail['hotel']}")
                st.write("Termasuk:")
                for item in detail['includes']:
                    st.write(f"✓ {item}")

                if st.button(f"Pesan Paket {tipe}", key=tipe):
                    st.success(f"Permintaan pemesanan paket {tipe} telah dikirim!")
    else:
        st.info("Paket wisata untuk negara ini akan segera tersedia!")

def halaman_faq():
    st.header("FAQ ❓")

    faq_list = [
        {"pertanyaan": "Berapa budget minimal untuk perjalanan?", 
         "jawaban": "Budget minimal yang disarankan adalah IDR 10.000.000."},
        {"pertanyaan": "Apakah aplikasi ini mendukung negara lain?", 
         "jawaban": "Saat ini kami mendukung Singapura, Thailand, dan Malaysia. Negara lain akan segera ditambahkan."},
        {"pertanyaan": "Bagaimana cara memesan paket wisata?", 
         "jawaban": "Anda dapat memesan paket wisata melalui halaman Paket Wisata dengan memilih paket yang sesuai."},
        {"pertanyaan": "Apakah informasi saya disimpan?", 
         "jawaban": "Data yang Anda masukkan hanya digunakan untuk sesi saat ini dan tidak disimpan permanen."},
        {"pertanyaan": "Apakah estimasi biaya sudah termasuk pajak?", 
         "jawaban": "Estimasi biaya belum termasuk pajak atau biaya tambahan lainnya."},
    ]

    for faq in faq_list:
        with st.expander(f"❓ {faq['pertanyaan']}"):
            st.write(f"💬 {faq['jawaban']}")

if __name__ == "__main__":
    main()
